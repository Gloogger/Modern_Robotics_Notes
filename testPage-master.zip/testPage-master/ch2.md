---
layout: post
mathjax: true
title: 'Kapitel 2'
description: blah blah blah blah
is_project_page: false
---


<p style="text-align:center;">
<button type="button" onclick="window.location.href='index.html';">Homepage</button>
<span style="float:left;"><button type="button" onclick="alert('This is the first chapter!')">Previous</button></span>
<span style="float:right;"><button type="button" onclick="window.location.href='ch3.html';">Next</button></span>
</p>

## blah
**blah**, **blah**, and **blah**r.

***
The omnipotent math shows that:

$$
1+1 = 2
$$
***

<p style="text-align:center;">
<button type="button" onclick="window.location.href='#top';">Back To Top</button>
<p>
